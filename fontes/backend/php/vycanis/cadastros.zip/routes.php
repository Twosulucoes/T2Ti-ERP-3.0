<?php

///////////////////////////////
// LOGIN
///////////////////////////////
// Authentication Manager middleware
$auth = new LoginController();
$exigirToken = getenv('EXIGIR_TOKEN') !== 'false';
$app->post('/login[/]', \LoginController::class . ":login");
$app->options('/login[/]', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

///////////////////////////////
// AUTHENTICATION
///////////////////////////////
// $app->get('/some-route[/]', \SomeRouteController::class . RESULT_LIST)->add($auth); // if you would like to use the Token to authenticate the access to routes, just insert "->add($auth)" at the end of the routes


///////////////////////////////
// MODULES
///////////////////////////////
// pessoa
$app->get('/pessoa[/]', \PessoaController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/pessoa/{id}', \PessoaController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/pessoa', \PessoaController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/pessoa', \PessoaController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/pessoa/{id}', \PessoaController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/pessoa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pessoa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador
$app->get('/colaborador[/]', \ColaboradorController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/colaborador/{id}', \ColaboradorController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/colaborador', \ColaboradorController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/colaborador', \ColaboradorController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/colaborador/{id}', \ColaboradorController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/colaborador', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// papel
$app->get('/papel[/]', \PapelController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/papel/{id}', \PapelController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/papel', \PapelController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/papel', \PapelController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/papel/{id}', \PapelController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/papel', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/papel/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// funcao
$app->get('/funcao[/]', \FuncaoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/funcao/{id}', \FuncaoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/funcao', \FuncaoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/funcao', \FuncaoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/funcao/{id}', \FuncaoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/funcao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/funcao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// estado-civil
$app->get('/estado-civil[/]', \EstadoCivilController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/estado-civil/{id}', \EstadoCivilController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/estado-civil', \EstadoCivilController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/estado-civil', \EstadoCivilController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/estado-civil/{id}', \EstadoCivilController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/estado-civil', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estado-civil/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/estado-civil/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cargo
$app->get('/cargo[/]', \CargoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cargo/{id}', \CargoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cargo', \CargoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cargo', \CargoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cargo/{id}', \CargoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cargo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cargo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cargo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// setor
$app->get('/setor[/]', \SetorController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/setor/{id}', \SetorController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/setor', \SetorController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/setor', \SetorController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/setor/{id}', \SetorController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/setor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/setor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador-situacao
$app->get('/colaborador-situacao[/]', \ColaboradorSituacaoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/colaborador-situacao/{id}', \ColaboradorSituacaoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/colaborador-situacao', \ColaboradorSituacaoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/colaborador-situacao', \ColaboradorSituacaoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/colaborador-situacao/{id}', \ColaboradorSituacaoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/colaborador-situacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-situacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-situacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tipo-admissao
$app->get('/tipo-admissao[/]', \TipoAdmissaoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/tipo-admissao/{id}', \TipoAdmissaoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/tipo-admissao', \TipoAdmissaoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/tipo-admissao', \TipoAdmissaoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/tipo-admissao/{id}', \TipoAdmissaoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/tipo-admissao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-admissao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-admissao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// colaborador-tipo
$app->get('/colaborador-tipo[/]', \ColaboradorTipoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/colaborador-tipo/{id}', \ColaboradorTipoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/colaborador-tipo', \ColaboradorTipoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/colaborador-tipo', \ColaboradorTipoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/colaborador-tipo/{id}', \ColaboradorTipoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/colaborador-tipo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-tipo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/colaborador-tipo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-grupo
$app->get('/produto-grupo[/]', \ProdutoGrupoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/produto-grupo/{id}', \ProdutoGrupoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/produto-grupo', \ProdutoGrupoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/produto-grupo', \ProdutoGrupoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/produto-grupo/{id}', \ProdutoGrupoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/produto-grupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-grupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-subgrupo
$app->get('/produto-subgrupo[/]', \ProdutoSubgrupoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/produto-subgrupo', \ProdutoSubgrupoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/produto-subgrupo', \ProdutoSubgrupoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/produto-subgrupo/{id}', \ProdutoSubgrupoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/produto-subgrupo', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-subgrupo/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-marca
$app->get('/produto-marca[/]', \ProdutoMarcaController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/produto-marca/{id}', \ProdutoMarcaController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/produto-marca', \ProdutoMarcaController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/produto-marca', \ProdutoMarcaController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/produto-marca/{id}', \ProdutoMarcaController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/produto-marca', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-marca/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto-unidade
$app->get('/produto-unidade[/]', \ProdutoUnidadeController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/produto-unidade/{id}', \ProdutoUnidadeController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/produto-unidade', \ProdutoUnidadeController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/produto-unidade', \ProdutoUnidadeController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/produto-unidade/{id}', \ProdutoUnidadeController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/produto-unidade', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto-unidade/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// produto
$app->get('/produto[/]', \ProdutoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/produto/{id}', \ProdutoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/produto', \ProdutoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/produto', \ProdutoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/produto/{id}', \ProdutoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/produto', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/produto/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco
$app->get('/banco[/]', \BancoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/banco/{id}', \BancoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/banco', \BancoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/banco', \BancoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/banco/{id}', \BancoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/banco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-agencia
$app->get('/banco-agencia[/]', \BancoAgenciaController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/banco-agencia/{id}', \BancoAgenciaController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/banco-agencia', \BancoAgenciaController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/banco-agencia', \BancoAgenciaController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/banco-agencia/{id}', \BancoAgenciaController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/banco-agencia', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-agencia/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// banco-conta-caixa
$app->get('/banco-conta-caixa[/]', \BancoContaCaixaController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/banco-conta-caixa', \BancoContaCaixaController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/banco-conta-caixa', \BancoContaCaixaController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/banco-conta-caixa/{id}', \BancoContaCaixaController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/banco-conta-caixa', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/banco-conta-caixa/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cep
$app->get('/cep[/]', \CepController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cep/{id}', \CepController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cep', \CepController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cep', \CepController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cep/{id}', \CepController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cep', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cep/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cep/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// uf
$app->get('/uf[/]', \UfController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/uf/{id}', \UfController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/uf', \UfController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/uf', \UfController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/uf/{id}', \UfController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/uf', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/uf/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/uf/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// municipio
$app->get('/municipio[/]', \MunicipioController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/municipio/{id}', \MunicipioController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/municipio', \MunicipioController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/municipio', \MunicipioController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/municipio/{id}', \MunicipioController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/municipio', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/municipio/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/municipio/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// ncm
$app->get('/ncm[/]', \NcmController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/ncm/{id}', \NcmController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/ncm', \NcmController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/ncm', \NcmController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/ncm/{id}', \NcmController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/ncm', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ncm/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/ncm/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cfop
$app->get('/cfop[/]', \CfopController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cfop/{id}', \CfopController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cfop', \CfopController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cfop', \CfopController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cfop/{id}', \CfopController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cfop', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cfop/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cfop/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-icms
$app->get('/cst-icms[/]', \CstIcmsController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cst-icms/{id}', \CstIcmsController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cst-icms', \CstIcmsController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cst-icms', \CstIcmsController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cst-icms/{id}', \CstIcmsController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cst-icms', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-icms/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-icms/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-ipi
$app->get('/cst-ipi[/]', \CstIpiController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cst-ipi/{id}', \CstIpiController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cst-ipi', \CstIpiController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cst-ipi', \CstIpiController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cst-ipi/{id}', \CstIpiController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cst-ipi', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-ipi/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-ipi/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-cofins
$app->get('/cst-cofins[/]', \CstCofinsController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cst-cofins/{id}', \CstCofinsController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cst-cofins', \CstCofinsController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cst-cofins', \CstCofinsController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cst-cofins/{id}', \CstCofinsController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cst-cofins', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-cofins/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-cofins/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cst-pis
$app->get('/cst-pis[/]', \CstPisController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cst-pis/{id}', \CstPisController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cst-pis', \CstPisController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cst-pis', \CstPisController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cst-pis/{id}', \CstPisController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cst-pis', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-pis/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cst-pis/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// csosn
$app->get('/csosn[/]', \CsosnController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/csosn/{id}', \CsosnController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/csosn', \CsosnController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/csosn', \CsosnController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/csosn/{id}', \CsosnController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/csosn', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/csosn/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/csosn/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// cnae
$app->get('/cnae[/]', \CnaeController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/cnae/{id}', \CnaeController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/cnae', \CnaeController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/cnae', \CnaeController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/cnae/{id}', \CnaeController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/cnae', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/cnae/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// pais
$app->get('/pais[/]', \PaisController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/pais/{id}', \PaisController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/pais', \PaisController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/pais', \PaisController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/pais/{id}', \PaisController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/pais', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pais/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/pais/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// vendedor
$app->get('/vendedor[/]', \VendedorController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/vendedor/{id}', \VendedorController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/vendedor', \VendedorController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/vendedor', \VendedorController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/vendedor/{id}', \VendedorController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/vendedor', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/vendedor/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/vendedor/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);


// nivel-formacao
$app->get('/nivel-formacao[/]', \NivelFormacaoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/nivel-formacao/{id}', \NivelFormacaoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/nivel-formacao', \NivelFormacaoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/nivel-formacao', \NivelFormacaoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/nivel-formacao/{id}', \NivelFormacaoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/nivel-formacao', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nivel-formacao/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/nivel-formacao/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tabela-preco
$app->get('/tabela-preco[/]', \TabelaPrecoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/tabela-preco/{id}', \TabelaPrecoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/tabela-preco', \TabelaPrecoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/tabela-preco', \TabelaPrecoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/tabela-preco/{id}', \TabelaPrecoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/tabela-preco', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tabela-preco/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tabela-preco/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tipo-relacionamento
$app->get('/tipo-relacionamento[/]', \TipoRelacionamentoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/tipo-relacionamento/{id}', \TipoRelacionamentoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/tipo-relacionamento', \TipoRelacionamentoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/tipo-relacionamento', \TipoRelacionamentoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/tipo-relacionamento/{id}', \TipoRelacionamentoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/tipo-relacionamento', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-relacionamento/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tipo-relacionamento/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-controle-acesso
$app->get('/view-controle-acesso[/]', \ViewControleAcessoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/view-controle-acesso/{id}', \ViewControleAcessoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/view-controle-acesso', \ViewControleAcessoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/view-controle-acesso', \ViewControleAcessoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/view-controle-acesso/{id}', \ViewControleAcessoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/view-controle-acesso', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-controle-acesso/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// view-pessoa-usuario
$app->get('/view-pessoa-usuario[/]', \ViewPessoaUsuarioController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/view-pessoa-usuario', \ViewPessoaUsuarioController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/view-pessoa-usuario/{id}', \ViewPessoaUsuarioController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/view-pessoa-usuario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/view-pessoa-usuario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// comissao-perfil
$app->get('/comissao-perfil[/]', \ComissaoPerfilController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/comissao-perfil/{id}', \ComissaoPerfilController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/comissao-perfil', \ComissaoPerfilController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/comissao-perfil', \ComissaoPerfilController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/comissao-perfil/{id}', \ComissaoPerfilController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/comissao-perfil', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/comissao-perfil/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/comissao-perfil/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// sindicato
$app->get('/sindicato[/]', \SindicatoController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/sindicato/{id}', \SindicatoController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/sindicato', \SindicatoController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/sindicato', \SindicatoController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/sindicato/{id}', \SindicatoController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/sindicato', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sindicato/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/sindicato/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-icms-custom-cab
$app->get('/tribut-icms-custom-cab[/]', \TributIcmsCustomCabController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/tribut-icms-custom-cab', \TributIcmsCustomCabController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/tribut-icms-custom-cab/{id}', \TributIcmsCustomCabController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/tribut-icms-custom-cab', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-icms-custom-cab/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

// tribut-grupo-tributario
$app->get('/tribut-grupo-tributario[/]', \TributGrupoTributarioController::class . RESULT_LIST)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->get('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . RESULT_OBJECT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->post('/tribut-grupo-tributario', \TributGrupoTributarioController::class . INSERT)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->put('/tribut-grupo-tributario', \TributGrupoTributarioController::class . UPDATE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->delete('/tribut-grupo-tributario/{id}', \TributGrupoTributarioController::class . DELETE)->add($exigirToken ? $auth : fn($request, $handler) => $handler->handle($request));
$app->options('/tribut-grupo-tributario', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/', \ControllerBase::class . BROWSER_OPTION_RESPONSE);
$app->options('/tribut-grupo-tributario/{id}', \ControllerBase::class . BROWSER_OPTION_RESPONSE);

