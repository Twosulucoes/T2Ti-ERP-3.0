<?php
class TabelaPrecoService extends ServiceBase
{
  public function getList()
  {
    return TabelaPrecoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return TabelaPrecoModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return TabelaPrecoModel::find($id);
  }

}