<?php
class UsuarioTokenService extends ServiceBase
{
  public function getList()
  {
    return UsuarioTokenModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return UsuarioTokenModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return UsuarioTokenModel::find($id);
  }

}