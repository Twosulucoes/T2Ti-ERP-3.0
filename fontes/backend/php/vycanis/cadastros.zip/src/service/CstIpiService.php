<?php
class CstIpiService extends ServiceBase
{
  public function getList()
  {
    return CstIpiModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CstIpiModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return CstIpiModel::find($id);
  }

}