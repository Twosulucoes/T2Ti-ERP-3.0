<?php
class CargoService extends ServiceBase
{
  public function getList()
  {
    return CargoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CargoModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return CargoModel::find($id);
  }

}