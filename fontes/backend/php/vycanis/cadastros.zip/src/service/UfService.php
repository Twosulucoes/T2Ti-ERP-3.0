<?php
class UfService extends ServiceBase
{
  public function getList()
  {
    return UfModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return UfModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return UfModel::find($id);
  }

}