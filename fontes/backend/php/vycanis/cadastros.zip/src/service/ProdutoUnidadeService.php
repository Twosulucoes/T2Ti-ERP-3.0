<?php
class ProdutoUnidadeService extends ServiceBase
{
  public function getList()
  {
    return ProdutoUnidadeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ProdutoUnidadeModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return ProdutoUnidadeModel::find($id);
  }

}