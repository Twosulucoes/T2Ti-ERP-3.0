<?php
use Illuminate\Database\Capsule\Manager as DB;
class ColaboradorService extends ServiceBase
{
	public function getList()
	{
		return ColaboradorModel::select()->get();
	} 

	public function getListFilter($filter)
	{
		return ColaboradorModel::whereRaw($filter->where, $filter->bindings)->get();
	}

	public function getObject(int $id)
	{
		return ColaboradorModel::find($id);
	}

	public function insert($objJson, $objModel) {
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->insertChildren($objJson, $objModel);
		});	
	}

	public function update($objJson, $objModel)
	{
		DB::transaction(function () use ($objJson, $objModel) {
			$objModel->save();
			$this->deleteChildren($objModel);
			$this->insertChildren($objJson, $objModel);
		});		
	}

	public function delete($object)
	{
		DB::transaction(function () use ($object) {
			$this->deleteChildren($object);
			parent::delete($object);
		});		
	} 

	public function insertChildren($objJson, $objModel)
	{
		// vendedor
		if (isset($objJson->vendedorModel)) {
			$vendedorModel = new VendedorModel();
			$vendedorModel->mapping($objJson->vendedorModel);
			$objModel->vendedorModel()->save($vendedorModel);
		}

		// colaboradorRelacionamento
		$colaboradorRelacionamentoModelListJson = $objJson->colaboradorRelacionamentoModelList;
		if ($colaboradorRelacionamentoModelListJson != null) {
			for ($i = 0; $i < count($colaboradorRelacionamentoModelListJson); $i++) {
				$colaboradorRelacionamento = new ColaboradorRelacionamentoModel();
				$colaboradorRelacionamento->mapping($colaboradorRelacionamentoModelListJson[$i]);
				$objModel->colaboradorRelacionamentoModelList()->save($colaboradorRelacionamento);
			}
		}

	}	

	public function deleteChildren($object)
	{
		VendedorModel::where('id_colaborador', $object->getIdAttribute())->delete();
		ColaboradorRelacionamentoModel::where('id_colaborador', $object->getIdAttribute())->delete();
	}	
 
}