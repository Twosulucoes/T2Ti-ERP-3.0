<?php
class CnaeService extends ServiceBase
{
  public function getList()
  {
    return CnaeModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return CnaeModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return CnaeModel::find($id);
  }

}