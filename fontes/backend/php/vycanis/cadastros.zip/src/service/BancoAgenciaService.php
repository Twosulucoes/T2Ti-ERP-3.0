<?php
class BancoAgenciaService extends ServiceBase
{
  public function getList()
  {
    return BancoAgenciaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return BancoAgenciaModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return BancoAgenciaModel::find($id);
  }

}