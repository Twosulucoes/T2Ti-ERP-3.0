<?php
class ColaboradorTipoService extends ServiceBase
{
  public function getList()
  {
    return ColaboradorTipoModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return ColaboradorTipoModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return ColaboradorTipoModel::find($id);
  }

}