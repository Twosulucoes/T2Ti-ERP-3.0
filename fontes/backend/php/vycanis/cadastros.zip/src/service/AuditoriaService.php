<?php
class AuditoriaService extends ServiceBase
{
  public function getList()
  {
    return AuditoriaModel::select()->get();
  } 

  public function getListFilter($filter)
  {
  	return AuditoriaModel::whereRaw($filter->where, $filter->bindings)->get();
  }

  public function getObject(int $id)
  {
    return AuditoriaModel::find($id);
  }

}