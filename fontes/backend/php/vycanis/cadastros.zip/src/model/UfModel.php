<?php
declare(strict_types=1);

class UfModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'uf';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomeAttribute()
	{
		return $this->attributes['nome'];
	}

	public function setNomeAttribute($nome)
	{
		$this->attributes['nome'] = $nome;
	}

	public function getSiglaAttribute()
	{
		return $this->attributes['sigla'];
	}

	public function setSiglaAttribute($sigla)
	{
		$this->attributes['sigla'] = $sigla;
	}

	public function getCodigoIbgeAttribute()
	{
		return $this->attributes['codigo_ibge'];
	}

	public function setCodigoIbgeAttribute($codigoIbge)
	{
		$this->attributes['codigo_ibge'] = $codigoIbge;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomeAttribute($object->nome);
				$this->setSiglaAttribute($object->sigla);
				$this->setCodigoIbgeAttribute($object->codigoIbge);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nome' => $this->getNomeAttribute(),
				'sigla' => $this->getSiglaAttribute(),
				'codigoIbge' => $this->getCodigoIbgeAttribute(),
			];
	}
}