<?php

/// transient class that stores the error object that will be returned to the client
class ResultJsonError implements \JsonSerializable
{
	private $status;
	private $message;
	private $error;
	private $trace;

	public function __construct(int $codigo, string $mensagem, ?Exception $erro)
	{
		$this->status = $codigo;
		$this->message = $mensagem;

		switch ($this->status) {
			case 400:
				$this->error = 'Bad Request';
				break;
			case 404:
				$this->error = 'Not Found';
				break;
			case 500:
				$this->error = 'Internal Server Error';
				break;
			default:
				$this->error = 'Not Mapped Error';
				break;
		}

		if ($erro != null) {
			// detalhes do erro só vão para o cliente com MOSTRAR_DETALHES_ERRO=true (desenvolvimento)
			if (getenv('MOSTRAR_DETALHES_ERRO') === 'true' || getenv('MOSTRAR_DETALHES_ERRO') === false) {
				$this->message = $this->message . " - Error: " . $erro->getMessage();
				$this->trace = $erro->getTraceAsString();
			} else {
				error_log($mensagem . ' - ' . $erro->getMessage() . "\n" . $erro->getTraceAsString());
			}
		}
	}

    /**
     * {@inheritdoc}
     */
    public function jsonSerialize()
    {
			return [
				'status' => $this->status,
				'message' => $this->message,
				'error' => $this->error,
				'trace' => $this->trace
			];
    }


}