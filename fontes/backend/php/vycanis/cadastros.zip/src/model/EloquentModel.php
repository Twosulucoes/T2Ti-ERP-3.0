<?php
require __DIR__ . '/../../../vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as Capsule;

$capsule = new Capsule;

$capsule->addConnection([
	'driver'		=> 'mysql',
	'host'			=> getenv('DB_HOST') ?: 'localhost',
	'port'			=> getenv('DB_PORT') ?: '3306',
	// com DB_DATABASE definido, o cabeçalho CNPJ da requisição é ignorado
	'database'	=> getenv('DB_DATABASE') ?: $cnpjConnection,
	'username'	=> getenv('DB_USERNAME') ?: 'root',
	'password'	=> getenv('DB_PASSWORD') !== false ? getenv('DB_PASSWORD') : 'root',
	'charset'	 	=> 'utf8',
	'collation' => 'utf8_unicode_ci',
	'prefix'		=> '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

abstract class EloquentModel extends \Illuminate\Database\Eloquent\Model {
	/**
		* Indicates if the model should be timestamped.
		* To disallow Eloquent to create created_at and updated_at fields in the database
		*
		* @var bool
	*/
	public $timestamps = false;
}