<?php
declare(strict_types=1);

class PaisModel extends EloquentModel implements \JsonSerializable
{
	/**
		* The table associated with the model.
		*
		* @var string
		*/
	protected $table = 'pais';

	/**
		* Eager Loading - Relationships that should always be loaded by default
		*
		* @var array
		*/
	protected $with = [
	];

	/**
		* Relations
		*/


	/**
		* Gets e Sets
		*/
	public function getIdAttribute()
	{
		return $this->attributes['id'];
	}

	public function setIdAttribute($id)
	{
		$this->attributes['id'] = $id;
	}

	public function getNomePtbrAttribute()
	{
		return $this->attributes['nome_ptbr'];
	}

	public function setNomePtbrAttribute($nomePtbr)
	{
		$this->attributes['nome_ptbr'] = $nomePtbr;
	}

	public function getNomeEnAttribute()
	{
		return $this->attributes['nome_en'];
	}

	public function setNomeEnAttribute($nomeEn)
	{
		$this->attributes['nome_en'] = $nomeEn;
	}

	public function getCodigoAttribute()
	{
		return $this->attributes['codigo'];
	}

	public function setCodigoAttribute($codigo)
	{
		$this->attributes['codigo'] = $codigo;
	}

	public function getSigla2Attribute()
	{
		return $this->attributes['sigla2'];
	}

	public function setSigla2Attribute($sigla2)
	{
		$this->attributes['sigla2'] = $sigla2;
	}

	public function getSigla3Attribute()
	{
		return $this->attributes['sigla3'];
	}

	public function setSigla3Attribute($sigla3)
	{
		$this->attributes['sigla3'] = $sigla3;
	}

	public function getCodigoBacenAttribute()
	{
		return $this->attributes['codigo_bacen'];
	}

	public function setCodigoBacenAttribute($codigoBacen)
	{
		$this->attributes['codigo_bacen'] = $codigoBacen;
	}

	
    
	/**
		* Mapping
		*/
	public function mapping($object)
	{
			if (isset($object)) {
				isset($object->id) ? $this->setIdAttribute($object->id) : $this->setIdAttribute(null);

				$this->setNomePtbrAttribute($object->nomePtbr);
				$this->setNomeEnAttribute($object->nomeEn);
				$this->setCodigoAttribute($object->codigo);
				$this->setSigla2Attribute($object->sigla2);
				$this->setSigla3Attribute($object->sigla3);
				$this->setCodigoBacenAttribute($object->codigoBacen);

				// link objects - lookups
			}
	}

    
	/**
		* Serialization
		* {@inheritdoc}
		*/
	public function jsonSerialize()
	{
			return [
				'id' => $this->getIdAttribute(),
				'nomePtbr' => $this->getNomePtbrAttribute(),
				'nomeEn' => $this->getNomeEnAttribute(),
				'codigo' => $this->getCodigoAttribute(),
				'sigla2' => $this->getSigla2Attribute(),
				'sigla3' => $this->getSigla3Attribute(),
				'codigoBacen' => $this->getCodigoBacenAttribute(),
			];
	}
}