<?php
class PessoaController extends ControllerBase
{

	private $pessoaService = null;

	public function __construct()
	{
		$this->pessoaService = new PessoaService();
	}

	public function getList($request, $response, $args)
	{
		try {
			if (count($request->getQueryParams()) > 0) {
				$filter = new Filter(parent::handleFilter($request));
				$resultList = $this->pessoaService->getListFilter($filter);
			} else {
				$resultList = $this->pessoaService->getList();
			}
			$return = json_encode($resultList);
			$response->getBody()->write($return);
			return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getList Pessoa]', $e);
		}
	}

	public function getObject($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->pessoaService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 404, 'Not Found [getObject Pessoa]', null);
			} else {
				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [getObject Pessoa]', $e);
		}
	}

	public function insert($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			if (!isset($objJson)) {
				return parent::handleError($response, 400, 'Invalid Object [insert Pessoa]', null);
			}

			$objModel = new PessoaModel();
			$objModel->mapping($objJson);

			$this->pessoaService->insert($objJson, $objModel);

			$return = json_encode($objModel);
			$response->getBody()->write($return);

			return $response
				->withStatus(201)
				->withHeader('Content-Type', 'application/json');
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [insert Pessoa]', $e);
		}
	}

	public function update($request, $response, $args)
	{
		try {
			$objJson = json_decode($request->getBody());

			$objFromDatabase = $this->pessoaService->getObject($objJson->id);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [update Pessoa]', null);
			} else {
				$objFromDatabase->mapping($objJson);

				$this->pessoaService->update($objJson, $objFromDatabase);
				$objFromDatabase = $this->pessoaService->getObject($objJson->id);

				$return = json_encode($objFromDatabase);
				$response->getBody()->write($return);
				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [update Pessoa]', $e);
		}
	}

	public function delete($request, $response, $args)
	{
		try {
			$objFromDatabase = $this->pessoaService->getObject($args['id']);

			if ($objFromDatabase == null) {
				return parent::handleError($response, 400, 'Invalid Object [delete Pessoa]', null);
			} else {
				$this->pessoaService->delete($objFromDatabase);

				return $response
					->withStatus(200)
					->withHeader('Content-Type', 'application/json');
			}
		} catch (Exception $e) {
			return parent::handleError($response, 500, 'Error [delete Pessoa]', $e);
		}
	}
}
