/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContratoHistoricoReajusteTab } from './ContratoHistoricoReajusteTab';
import { ContratoPrevFaturamentoTab } from './ContratoPrevFaturamentoTab';
import { ContratoHistFaturamentoTab } from './ContratoHistFaturamentoTab';

export const ContratoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Contrato">
				<ContratoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Histórico de Reajustes">
				<ContratoHistoricoReajusteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Previsão de Faturamento">
				<ContratoPrevFaturamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Histórico de Faturamento">
				<ContratoHistFaturamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContratoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};