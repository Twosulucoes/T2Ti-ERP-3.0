import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import contrato from '../page/contrato';
import tipoContrato from '../page/tipoContrato';
import contratoTipoServico from '../page/contratoTipoServico';
import contratoSolicitacaoServico from '../page/contratoSolicitacaoServico';
import contratoTemplate from '../page/contratoTemplate';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/tipo-contrato'
					state={{ _scrollToTop: true }}
					primaryText='Tipo de Contrato'
					leftIcon={<tipoContrato.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contrato-tipo-servico'
					state={{ _scrollToTop: true }}
					primaryText='Tipo de Serviço'
					leftIcon={<contratoTipoServico.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contrato-solicitacao-servico'
					state={{ _scrollToTop: true }}
					primaryText='Solicitação de Serviço'
					leftIcon={<contratoSolicitacaoServico.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contrato-template'
					state={{ _scrollToTop: true }}
					primaryText='Template'
					leftIcon={<contratoTemplate.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/contrato'
					state={{ _scrollToTop: true }}
					primaryText='Contrato'
					leftIcon={<contrato.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
