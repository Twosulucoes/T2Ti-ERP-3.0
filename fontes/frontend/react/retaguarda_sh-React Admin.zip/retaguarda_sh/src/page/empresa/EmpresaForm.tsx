/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { NfeConfiguracaoTab } from './NfeConfiguracaoTab';
import { PdvPlanoPagamentoTab } from './PdvPlanoPagamentoTab';
import { AcbrMonitorPortaTab } from './AcbrMonitorPortaTab';
import { EmpresaPlanoTab } from './EmpresaPlanoTab';
import { AdmModuloTab } from './AdmModuloTab';

export const EmpresaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Empresa">
				<EmpresaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Nfe Configuracao">
				<NfeConfiguracaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Pdv Plano Pagamento">
				<PdvPlanoPagamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Acbr Monitor Porta">
				<AcbrMonitorPortaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Empresa Plano">
				<EmpresaPlanoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Adm Modulo">
				<AdmModuloTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const EmpresaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};