/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ErpTipoPlanoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","valor","frequencia"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ErpTipoPlanoSmallScreenList : ErpTipoPlanoBigScreenList;

	return (
		<List
			title="Erp Tipo Plano"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ErpTipoPlanoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.valor }
			tertiaryText={ (record) => record.frequencia }
		/>
	);
}

const ErpTipoPlanoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="frequencia" label="Frequencia" />
			<TextField source="acessoTotal" label="Acesso Total" />
			<TextField source="ativo" label="Ativo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ErpTipoPlanoList;
