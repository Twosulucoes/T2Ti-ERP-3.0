/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { EtiquetaTemplateTab } from './EtiquetaTemplateTab';

export const EtiquetaLayoutForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Layout">
				<EtiquetaLayoutTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Templates">
				<EtiquetaTemplateTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const EtiquetaLayoutTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};