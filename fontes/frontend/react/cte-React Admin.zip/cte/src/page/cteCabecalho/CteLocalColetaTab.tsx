/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteLocalColetaDomain from '../../data/domain/CteLocalColetaDomain';

class CteLocalColeta {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteLocalColeta {
		const cteLocalColeta = new CteLocalColeta();
		cteLocalColeta.id = Date.now();
		cteLocalColeta.statusCrud = "C";
		return cteLocalColeta;
	}
}

export const CteLocalColetaTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteLocalColeta,
		setCurrentRecord: (record: CteLocalColeta) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteLocalColetaDomain.getUf },
	];

	return (
		<CrudChildTab
			title="Local Coleta"
			recordContext="cteCabecalho"
			fieldSource="cteLocalColetaModelList"
			newObject={ CteLocalColeta.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};