/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
} from "react-admin";
import { Box } from "@mui/material";

export const CteRodoviarioOccForm = () => (
	<SimpleForm>
		<ListButton />
		</Box>
	</SimpleForm>
);