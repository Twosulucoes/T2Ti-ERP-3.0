class CteInformacaoNfCargaDomain {
	static getTipoUnidadeCarga(tipoUnidadeCarga: string) { 
		switch (tipoUnidadeCarga) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoUnidadeCarga(tipoUnidadeCarga: string) { 
		switch (tipoUnidadeCarga) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default CteInformacaoNfCargaDomain;