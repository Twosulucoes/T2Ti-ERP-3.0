/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FiscalEstadualPorteDomain from '../../data/domain/FiscalEstadualPorteDomain';

const FiscalEstadualPorteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["uf","codigo","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalEstadualPorteSmallScreenList : FiscalEstadualPorteBigScreenList;

	return (
		<List
			title="Porte Estadual"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalEstadualPorteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.uf }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.nome }
		/>
	);
}

const FiscalEstadualPorteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Uf"
				render={record => FiscalEstadualPorteDomain.getUf(record.uf)}
			/>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalEstadualPorteList;
