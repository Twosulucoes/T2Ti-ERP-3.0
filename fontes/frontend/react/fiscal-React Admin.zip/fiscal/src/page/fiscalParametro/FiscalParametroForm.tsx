/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FiscalInscricoesSubstitutasTab } from './FiscalInscricoesSubstitutasTab';

export const FiscalParametroForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Parâmetros">
				<FiscalParametroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Inscrições Substitutas">
				<FiscalInscricoesSubstitutasTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FiscalParametroTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};