/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FiscalLivroForm } from "./FiscalLivroForm";
import { transformNestedData } from "../../infra/utils";

const FiscalLivroEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FiscalLivroForm />
		</Edit>
	);
};

export default FiscalLivroEdit;