/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FiscalTermoTab } from './FiscalTermoTab';

export const FiscalLivroForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Livros">
				<FiscalLivroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Termos">
				<FiscalTermoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FiscalLivroTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};