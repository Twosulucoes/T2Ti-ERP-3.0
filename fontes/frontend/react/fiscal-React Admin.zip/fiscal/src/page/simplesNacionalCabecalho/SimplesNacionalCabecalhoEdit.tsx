/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { SimplesNacionalCabecalhoForm } from "./SimplesNacionalCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const SimplesNacionalCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<SimplesNacionalCabecalhoForm />
		</Edit>
	);
};

export default SimplesNacionalCabecalhoEdit;