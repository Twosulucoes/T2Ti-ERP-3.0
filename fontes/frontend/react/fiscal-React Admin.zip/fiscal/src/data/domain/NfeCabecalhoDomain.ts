class NfeCabecalhoDomain {
	static getCodigoModelo(codigoModelo: string) { 
		switch (codigoModelo) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setCodigoModelo(codigoModelo: string) { 
		switch (codigoModelo) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getSerie(serie: string) { 
		switch (serie) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setSerie(serie: string) { 
		switch (serie) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getTipoOperacao(tipoOperacao: string) { 
		switch (tipoOperacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoOperacao(tipoOperacao: string) { 
		switch (tipoOperacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getLocalDestino(localDestino: string) { 
		switch (localDestino) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setLocalDestino(localDestino: string) { 
		switch (localDestino) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getFormatoImpressaoDanfe(formatoImpressaoDanfe: string) { 
		switch (formatoImpressaoDanfe) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setFormatoImpressaoDanfe(formatoImpressaoDanfe: string) { 
		switch (formatoImpressaoDanfe) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getTipoEmissao(tipoEmissao: string) { 
		switch (tipoEmissao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoEmissao(tipoEmissao: string) { 
		switch (tipoEmissao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getDigitoChaveAcesso(digitoChaveAcesso: string) { 
		switch (digitoChaveAcesso) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setDigitoChaveAcesso(digitoChaveAcesso: string) { 
		switch (digitoChaveAcesso) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getAmbiente(ambiente: string) { 
		switch (ambiente) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setAmbiente(ambiente: string) { 
		switch (ambiente) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getFinalidadeEmissao(finalidadeEmissao: string) { 
		switch (finalidadeEmissao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setFinalidadeEmissao(finalidadeEmissao: string) { 
		switch (finalidadeEmissao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getConsumidorOperacao(consumidorOperacao: string) { 
		switch (consumidorOperacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setConsumidorOperacao(consumidorOperacao: string) { 
		switch (consumidorOperacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getConsumidorPresenca(consumidorPresenca: string) { 
		switch (consumidorPresenca) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setConsumidorPresenca(consumidorPresenca: string) { 
		switch (consumidorPresenca) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getProcessoEmissao(processoEmissao: string) { 
		switch (processoEmissao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setProcessoEmissao(processoEmissao: string) { 
		switch (processoEmissao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getRegimeEspecialTributacao(regimeEspecialTributacao: string) { 
		switch (regimeEspecialTributacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setRegimeEspecialTributacao(regimeEspecialTributacao: string) { 
		switch (regimeEspecialTributacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getComexUfEmbarque(comexUfEmbarque: string) { 
		switch (comexUfEmbarque) { 
			case '': 
			case '0': 
				return 'AC'; 
			case '1': 
				return 'AL'; 
			case '2': 
				return 'AP'; 
			case '3': 
				return 'AM'; 
			case '4': 
				return 'BA'; 
			case '5': 
				return 'CE'; 
			case '6': 
				return 'DF'; 
			case '7': 
				return 'ES'; 
			case '8': 
				return 'GO'; 
			case '9': 
				return 'MA'; 
			case '10': 
				return 'MT'; 
			case '11': 
				return 'MS'; 
			case '12': 
				return 'MG'; 
			case '13': 
				return 'PA'; 
			case '14': 
				return 'PB'; 
			case '15': 
				return 'PR'; 
			case '16': 
				return 'PE'; 
			case '17': 
				return 'PI'; 
			case '18': 
				return 'RJ'; 
			case '19': 
				return 'RN'; 
			case '20': 
				return 'RS'; 
			case '21': 
				return 'RO'; 
			case '22': 
				return 'RR'; 
			case '23': 
				return 'SC'; 
			case '24': 
				return 'SP'; 
			case '25': 
				return 'SE'; 
			case '26': 
				return 'TO'; 
			default: 
				return null; 
		} 
	} 

	static setComexUfEmbarque(comexUfEmbarque: string) { 
		switch (comexUfEmbarque) { 
			case 'AC': 
				return '0'; 
			case 'AL': 
				return '1'; 
			case 'AP': 
				return '2'; 
			case 'AM': 
				return '3'; 
			case 'BA': 
				return '4'; 
			case 'CE': 
				return '5'; 
			case 'DF': 
				return '6'; 
			case 'ES': 
				return '7'; 
			case 'GO': 
				return '8'; 
			case 'MA': 
				return '9'; 
			case 'MT': 
				return '10'; 
			case 'MS': 
				return '11'; 
			case 'MG': 
				return '12'; 
			case 'PA': 
				return '13'; 
			case 'PB': 
				return '14'; 
			case 'PR': 
				return '15'; 
			case 'PE': 
				return '16'; 
			case 'PI': 
				return '17'; 
			case 'RJ': 
				return '18'; 
			case 'RN': 
				return '19'; 
			case 'RS': 
				return '20'; 
			case 'RO': 
				return '21'; 
			case 'RR': 
				return '22'; 
			case 'SC': 
				return '23'; 
			case 'SP': 
				return '24'; 
			case 'SE': 
				return '25'; 
			case 'TO': 
				return '26'; 
			default: 
				return null; 
		} 
	}

	static getStatusNota(statusNota: string) { 
		switch (statusNota) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setStatusNota(statusNota: string) { 
		switch (statusNota) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default NfeCabecalhoDomain;