import UsuarioIcon from "@mui/icons-material/Apps";
import UsuarioList from "./UsuarioList";
import UsuarioCreate from "./UsuarioCreate";
import UsuarioEdit from "./UsuarioEdit";

export default {
	list: UsuarioList,
	create: UsuarioCreate,
	edit: UsuarioEdit,
	icon: UsuarioIcon,
};
