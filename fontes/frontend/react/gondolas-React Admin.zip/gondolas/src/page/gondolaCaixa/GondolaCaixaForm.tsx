/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { GondolaArmazenamentoTab } from './GondolaArmazenamentoTab';

export const GondolaCaixaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Caixa">
				<GondolaCaixaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Armazenamento">
				<GondolaArmazenamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const GondolaCaixaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};