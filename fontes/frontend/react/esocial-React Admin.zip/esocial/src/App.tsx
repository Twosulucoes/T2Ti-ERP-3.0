import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import ptBrMessages from './translations/pt-br';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import esocialNaturezaJuridica from './page/esocialNaturezaJuridica';
import esocialRubrica from './page/esocialRubrica';
import esocialTipoAfastamento from './page/esocialTipoAfastamento';
import esocialMotivoDesligamento from './page/esocialMotivoDesligamento';
import esocialClassificacaoTribut from './page/esocialClassificacaoTribut';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'en') {
			return import('./translations/en').then(messages => messages.default);
		}

		// Português do Brasil é o idioma padrão
		return ptBrMessages;
	},
	'pt-br',
	[
		{ locale: 'pt-br', name: 'Português Brasil' },
		{ locale: 'en', name: 'English' },
	]
);

const store = localStorageStore(undefined, 'esocial');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - eSocial (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='esocial-natureza-juridica' {...esocialNaturezaJuridica} options={{ label: 'Natureza Jurídica' }} />
			<Resource name='esocial-rubrica' {...esocialRubrica} options={{ label: 'Rubrica' }} />
			<Resource name='esocial-tipo-afastamento' {...esocialTipoAfastamento} options={{ label: 'Tipo Afastamento' }} />
			<Resource name='esocial-motivo-desligamento' {...esocialMotivoDesligamento} options={{ label: 'Motivo Desligamento' }} />
			<Resource name='esocial-classificacao-tribut' {...esocialClassificacaoTribut} options={{ label: 'Classificação Tributária' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;