/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import RequisicaoInternaCabecalhoDomain from '../../data/domain/RequisicaoInternaCabecalhoDomain';

const RequisicaoInternaCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataRequisicao","situacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? RequisicaoInternaCabecalhoSmallScreenList : RequisicaoInternaCabecalhoBigScreenList;

	return (
		<List
			title="Requisicao Interna"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const RequisicaoInternaCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataRequisicao }
			tertiaryText={ (record) => record.situacao }
		/>
	);
}

const RequisicaoInternaCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataRequisicao" label="Data Requisicao" />
			<FunctionField
				label="Situacao"
				render={record => RequisicaoInternaCabecalhoDomain.getSituacao(record.situacao)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default RequisicaoInternaCabecalhoList;
