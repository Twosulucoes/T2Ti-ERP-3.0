/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { RequisicaoInternaCabecalhoForm } from "./RequisicaoInternaCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const RequisicaoInternaCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<RequisicaoInternaCabecalhoForm />
		</Create>
	);
};

export default RequisicaoInternaCabecalhoCreate;