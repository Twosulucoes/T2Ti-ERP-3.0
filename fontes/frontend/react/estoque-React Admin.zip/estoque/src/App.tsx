import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import ptBrMessages from './translations/pt-br';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import requisicaoInternaCabecalho from './page/requisicaoInternaCabecalho';
import estoqueReajusteCabecalho from './page/estoqueReajusteCabecalho';
import estoqueCor from './page/estoqueCor';
import estoqueTamanho from './page/estoqueTamanho';
import estoqueSabor from './page/estoqueSabor';
import estoqueMarca from './page/estoqueMarca';
import estoqueGrade from './page/estoqueGrade';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'en') {
			return import('./translations/en').then(messages => messages.default);
		}

		// Português do Brasil é o idioma padrão
		return ptBrMessages;
	},
	'pt-br',
	[
		{ locale: 'pt-br', name: 'Português Brasil' },
		{ locale: 'en', name: 'English' },
	]
);

const store = localStorageStore(undefined, 'estoque');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Controle de Estoque (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='requisicao-interna-cabecalho' {...requisicaoInternaCabecalho} options={{ label: 'Requisicao Interna' }} />
			<Resource name='estoque-reajuste-cabecalho' {...estoqueReajusteCabecalho} options={{ label: 'Reajuste de Preços' }} />
			<Resource name='estoque-cor' {...estoqueCor} options={{ label: 'Cores' }} />
			<Resource name='estoque-tamanho' {...estoqueTamanho} options={{ label: 'Tamanhos' }} />
			<Resource name='estoque-sabor' {...estoqueSabor} options={{ label: 'Sabores' }} />
			<Resource name='estoque-marca' {...estoqueMarca} options={{ label: 'Marcas' }} />
			<Resource name='estoque-grade' {...estoqueGrade} options={{ label: 'Grade de Estoque' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;