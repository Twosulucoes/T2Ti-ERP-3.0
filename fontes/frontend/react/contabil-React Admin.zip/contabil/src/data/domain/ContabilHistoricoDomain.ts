class ContabilHistoricoDomain {
	static getPedeComplemento(pedeComplemento: string) { 
		switch (pedeComplemento) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPedeComplemento(pedeComplemento: string) { 
		switch (pedeComplemento) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilHistoricoDomain;