class LancaCentroResultadoDomain {
	static getOrigemDeRateio(origemDeRateio: string) { 
		switch (origemDeRateio) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setOrigemDeRateio(origemDeRateio: string) { 
		switch (origemDeRateio) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default LancaCentroResultadoDomain;