/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const RateioCentroResultadoCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["centroResultadoModel.descricao","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? RateioCentroResultadoCabSmallScreenList : RateioCentroResultadoCabBigScreenList;

	return (
		<List
			title="Rateio Centro Resultado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const RateioCentroResultadoCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.centroResultadoModel.descricao }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const RateioCentroResultadoCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Centro Resultado" source="centroResultadoModel.id" reference="centro-resultado" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default RateioCentroResultadoCabList;
