/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContabilTermoTab } from './ContabilTermoTab';

export const ContabilLivroForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Livros">
				<ContabilLivroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Termos">
				<ContabilTermoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContabilLivroTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};