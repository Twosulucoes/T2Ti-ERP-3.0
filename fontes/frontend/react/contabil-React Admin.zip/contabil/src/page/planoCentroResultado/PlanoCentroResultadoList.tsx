/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PlanoCentroResultadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","mascara","niveis"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PlanoCentroResultadoSmallScreenList : PlanoCentroResultadoBigScreenList;

	return (
		<List
			title="Plano Centro Resultado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PlanoCentroResultadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.mascara }
			tertiaryText={ (record) => record.niveis }
		/>
	);
}

const PlanoCentroResultadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="mascara" label="Mascara" />
			<TextField source="niveis" label="Niveis" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PlanoCentroResultadoList;
