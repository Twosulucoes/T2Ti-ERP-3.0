/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PlanoContaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","dataInclusao","mascara"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PlanoContaSmallScreenList : PlanoContaBigScreenList;

	return (
		<List
			title="Plano de Contas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PlanoContaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.dataInclusao }
			tertiaryText={ (record) => record.mascara }
		/>
	);
}

const PlanoContaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<TextField source="mascara" label="Mascara" />
			<TextField source="niveis" label="Niveis" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PlanoContaList;
