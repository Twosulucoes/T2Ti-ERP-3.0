/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilHistoricoDomain from '../../data/domain/ContabilHistoricoDomain';

const ContabilHistoricoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","pedeComplemento","historico"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilHistoricoSmallScreenList : ContabilHistoricoBigScreenList;

	return (
		<List
			title="Históricos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilHistoricoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.pedeComplemento }
			tertiaryText={ (record) => record.historico }
		/>
	);
}

const ContabilHistoricoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Pede Complemento"
				render={record => ContabilHistoricoDomain.getPedeComplemento(record.pedeComplemento)}
			/>
			<TextField source="historico" label="Historico" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilHistoricoList;
