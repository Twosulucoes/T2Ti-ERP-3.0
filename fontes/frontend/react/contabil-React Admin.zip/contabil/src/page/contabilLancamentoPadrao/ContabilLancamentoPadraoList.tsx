/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContabilLancamentoPadraoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","historico","idContaDebito"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilLancamentoPadraoSmallScreenList : ContabilLancamentoPadraoBigScreenList;

	return (
		<List
			title="Lancamento Padrão"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilLancamentoPadraoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.historico }
			tertiaryText={ (record) => record.idContaDebito }
		/>
	);
}

const ContabilLancamentoPadraoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="descricao" label="Descricao" />
			<TextField source="historico" label="Historico" />
			<TextField source="idContaDebito" label="Id Conta Debito" />
			<TextField source="idContaCredito" label="Id Conta Credito" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilLancamentoPadraoList;
