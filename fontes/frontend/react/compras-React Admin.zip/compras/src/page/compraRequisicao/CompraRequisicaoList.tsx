/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CompraRequisicaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["compraTipoRequisicaoModel.nome","viewPessoaColaboradorModel.nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CompraRequisicaoSmallScreenList : CompraRequisicaoBigScreenList;

	return (
		<List
			title="Requisição"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CompraRequisicaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.compraTipoRequisicaoModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const CompraRequisicaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Compra Tipo Requisicao" source="compraTipoRequisicaoModel.id" reference="compra-tipo-requisicao" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="descricao" label="Descricao" />
			<TextField source="dataRequisicao" label="Data Requisicao" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CompraRequisicaoList;
