/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CompraCotacaoDetalhe {
	constructor(
		public id = 0,
		public produtoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public quantidade = null,
		public valorUnitario = null,
		public valorSubtotal = null,
		public taxaDesconto = null,
		public valorDesconto = null,
		public valorTotal = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CompraCotacaoDetalhe {
		const compraCotacaoDetalhe = new CompraCotacaoDetalhe();
		compraCotacaoDetalhe.id = Date.now();
		compraCotacaoDetalhe.statusCrud = "C";
		return compraCotacaoDetalhe;
	}
}

export const CompraCotacaoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: CompraCotacaoDetalhe,
		setCurrentRecord: (record: CompraCotacaoDetalhe) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								produtoModel: {
						  		...currentRecord.produtoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='quantidade'
					label='Quantidade'
					helperText='Informe os dados para o campo Quantidade'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									quantidade: e.target.value,
								});
							}} format={(_: any) => currentRecord.quantidade ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorUnitario'
					label='Valor Unitario'
					helperText='Informe os dados para o campo Valor Unitario'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorUnitario: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorUnitario ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorSubtotal'
					label='Valor Subtotal'
					helperText='Informe os dados para o campo Valor Subtotal'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorSubtotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorSubtotal ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='taxaDesconto'
					label='Taxa Desconto'
					helperText='Informe os dados para o campo Taxa Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									taxaDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.taxaDesconto ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorDesconto'
					label='Valor Desconto'
					helperText='Informe os dados para o campo Valor Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorDesconto ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorTotal'
					label='Valor Total'
					helperText='Informe os dados para o campo Valor Total'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorTotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorTotal ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
	];

	return (
		<CrudChildTab
			title="Itens Cotação"
			recordContext="compraCotacao"
			fieldSource="compraCotacaoDetalheModelList"
			newObject={ CompraCotacaoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};