/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CompraPedidoForm } from "./CompraPedidoForm";
import { transformNestedData } from "../../infra/utils";

const CompraPedidoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CompraPedidoForm />
		</Edit>
	);
};

export default CompraPedidoEdit;