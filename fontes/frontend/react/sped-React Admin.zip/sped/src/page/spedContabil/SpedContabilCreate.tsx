import {
	Create,
} from "react-admin";
import { SpedContabilForm } from "./SpedContabilForm";

const SpedContabilCreate = () => {
	return (
		<Create>
			<SpedContabilForm />
		</Create>
	);
};

export default SpedContabilCreate;