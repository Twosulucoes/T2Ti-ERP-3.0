/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EfdReinfList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataEmissao","periodoInicial","periodoFinal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EfdReinfSmallScreenList : EfdReinfBigScreenList;

	return (
		<List
			title="EFD REINF"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EfdReinfSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataEmissao }
			secondaryText={ (record) => record.periodoInicial }
			tertiaryText={ (record) => record.periodoFinal }
		/>
	);
}

const EfdReinfBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="periodoInicial" label="Periodo Inicial" />
			<TextField source="periodoFinal" label="Periodo Final" />
			<TextField source="finalidadeArquivo" label="Finalidade Arquivo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EfdReinfList;
