/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FolhaEventoDomain from '../../data/domain/FolhaEventoDomain';

const FolhaEventoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaEventoSmallScreenList : FolhaEventoBigScreenList;

	return (
		<List
			title="Eventos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaEventoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const FolhaEventoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Base Calculo"
				render={record => FolhaEventoDomain.getBaseCalculo(record.baseCalculo)}
			/>
			<FunctionField
				label="Tipo"
				render={record => FolhaEventoDomain.getTipo(record.tipo)}
			/>
			<FunctionField
				label="Unidade"
				render={record => FolhaEventoDomain.getUnidade(record.unidade)}
			/>
			<NumberField source="taxa" label="Taxa" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaEventoList;
