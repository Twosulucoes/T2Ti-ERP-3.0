/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FolhaInssForm } from "./FolhaInssForm";
import { transformNestedData } from "../../infra/utils";

const FolhaInssEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FolhaInssForm />
		</Edit>
	);
};

export default FolhaInssEdit;