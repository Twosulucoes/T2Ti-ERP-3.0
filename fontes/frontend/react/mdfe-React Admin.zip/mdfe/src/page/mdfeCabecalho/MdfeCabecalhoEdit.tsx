/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { MdfeCabecalhoForm } from "./MdfeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const MdfeCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<MdfeCabecalhoForm />
		</Edit>
	);
};

export default MdfeCabecalhoEdit;