/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const MdfeInformacaoNfeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeMunicipioDescarregaModel.nomeMunicipio","chaveNfe","segundoCodigoBarra"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeInformacaoNfeSmallScreenList : MdfeInformacaoNfeBigScreenList;

	return (
		<List
			title="Informacao NFe"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeInformacaoNfeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeMunicipioDescarregaModel.nomeMunicipio }
			secondaryText={ (record) => record.chaveNfe }
			tertiaryText={ (record) => record.segundoCodigoBarra }
		/>
	);
}

const MdfeInformacaoNfeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Municipio Descarrega" source="mdfeMunicipioDescarregaModel.id" reference="mdfe-municipio-descarrega" sortable={false}>
				<TextField source="nomeMunicipio" />
			</ReferenceField>
			<TextField source="chaveNfe" label="Chave Nfe" />
			<TextField source="segundoCodigoBarra" label="Segundo Codigo Barra" />
			<TextField source="indicadorReentrega" label="Indicador Reentrega" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeInformacaoNfeList;
