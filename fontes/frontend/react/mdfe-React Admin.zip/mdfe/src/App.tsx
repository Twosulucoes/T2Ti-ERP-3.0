import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import ptBrMessages from './translations/pt-br';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import mdfeCabecalho from './page/mdfeCabecalho';
import mdfeInformacaoCte from './page/mdfeInformacaoCte';
import mdfeInformacaoNfe from './page/mdfeInformacaoNfe';
import mdfeRodoviarioMotorista from './page/mdfeRodoviarioMotorista';
import mdfeRodoviarioVeiculo from './page/mdfeRodoviarioVeiculo';
import mdfeRodoviarioPedagio from './page/mdfeRodoviarioPedagio';
import mdfeRodoviarioCiot from './page/mdfeRodoviarioCiot';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'en') {
			return import('./translations/en').then(messages => messages.default);
		}

		// Português do Brasil é o idioma padrão
		return ptBrMessages;
	},
	'pt-br',
	[
		{ locale: 'pt-br', name: 'Português Brasil' },
		{ locale: 'en', name: 'English' },
	]
);

const store = localStorageStore(undefined, 'mdfe');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - MDFe (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='mdfe-cabecalho' {...mdfeCabecalho} options={{ label: 'MDFe' }} />
			<Resource name='mdfe-informacao-cte' {...mdfeInformacaoCte} options={{ label: 'Informacão CTE' }} />
			<Resource name='mdfe-informacao-nfe' {...mdfeInformacaoNfe} options={{ label: 'Informacao NFe' }} />
			<Resource name='mdfe-rodoviario-motorista' {...mdfeRodoviarioMotorista} options={{ label: 'Rodoviario Motorista' }} />
			<Resource name='mdfe-rodoviario-veiculo' {...mdfeRodoviarioVeiculo} options={{ label: 'Rodoviario Veiculo' }} />
			<Resource name='mdfe-rodoviario-pedagio' {...mdfeRodoviarioPedagio} options={{ label: 'Rodoviario Pedagio' }} />
			<Resource name='mdfe-rodoviario-ciot' {...mdfeRodoviarioCiot} options={{ label: 'Rodoviario CIOT' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;