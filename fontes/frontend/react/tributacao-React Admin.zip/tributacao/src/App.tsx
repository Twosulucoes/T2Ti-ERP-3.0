import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import ptBrMessages from './translations/pt-br';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import tributIcmsCustomCab from './page/tributIcmsCustomCab';
import tributConfiguraOfGt from './page/tributConfiguraOfGt';
import tributGrupoTributario from './page/tributGrupoTributario';
import tributOperacaoFiscal from './page/tributOperacaoFiscal';
import tributIss from './page/tributIss';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'en') {
			return import('./translations/en').then(messages => messages.default);
		}

		// Português do Brasil é o idioma padrão
		return ptBrMessages;
	},
	'pt-br',
	[
		{ locale: 'pt-br', name: 'Português Brasil' },
		{ locale: 'en', name: 'English' },
	]
);

const store = localStorageStore(undefined, 'tributacao');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Tributação (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='tribut-icms-custom-cab' {...tributIcmsCustomCab} options={{ label: 'ICMS Customizado' }} />
			<Resource name='tribut-configura-of-gt' {...tributConfiguraOfGt} options={{ label: 'Configura Tributação' }} />
			<Resource name='tribut-grupo-tributario' {...tributGrupoTributario} options={{ label: 'Grupo Tributário' }} />
			<Resource name='tribut-operacao-fiscal' {...tributOperacaoFiscal} options={{ label: 'Operação Fiscal' }} />
			<Resource name='tribut-iss' {...tributIss} options={{ label: 'ISS' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;