/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	NumberInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const TributOperacaoFiscalForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='cfop'
					label='CFOP'
					helperText='Informe os dados para o campo Cfop'
					validate={[]}
				/>
			</Box>
			<Box flex={9}>
				<TextInput
					source='descricao'
					label='Descrição'
					helperText='Informe os dados para o campo Descricao[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricaoNaNf'
					label='Descrição Na Nota Fiscal'
					helperText='Informe os dados para o campo Descricao Na Nf[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observação'
					helperText='Informe os dados para o campo Observacao'
					multiline
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);