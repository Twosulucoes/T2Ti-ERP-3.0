/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import TributGrupoTributarioDomain from '../../data/domain/TributGrupoTributarioDomain';

const TributGrupoTributarioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","origemMercadoria","observacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TributGrupoTributarioSmallScreenList : TributGrupoTributarioBigScreenList;

	return (
		<List
			title="Grupo Tributário"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TributGrupoTributarioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.origemMercadoria }
			tertiaryText={ (record) => record.observacao }
		/>
	);
}

const TributGrupoTributarioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Origem Mercadoria"
				render={record => TributGrupoTributarioDomain.getOrigemMercadoria(record.origemMercadoria)}
			/>
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TributGrupoTributarioList;
