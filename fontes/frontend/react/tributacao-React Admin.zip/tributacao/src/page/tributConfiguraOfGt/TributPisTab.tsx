/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	SelectInput,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const TributPisTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<SelectInput
					label='CST'
					source='tributPisModel.cstPis'
					helperText='Informe os dados para o campo Cst Pis'
					choices={ [{"id":"00","name":"00"},{"id":"10","name":"10"},{"id":"20","name":"20"},{"id":"30","name":"30"},{"id":"40","name":"40"},{"id":"41","name":"41"},{"id":"50","name":"50"},{"id":"51","name":"51"},{"id":"60","name":"60"},{"id":"70","name":"70"},{"id":"90","name":"90"}] }  
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Modalidade Base Cálculo'
					source='tributPisModel.modalidadeBaseCalculo'
					helperText='Informe os dados para o campo Modalidade Base Calculo'
					choices={ [{"id":"0","name":"0-Percentual"},{"id":"1","name":"1-Unidade"}] }  
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='tributPisModel.efdTabela435'
					label='Código Apuração EFD'
					helperText='Informe os dados para o campo Efd Tabela 435[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributPisModel.porcentoBaseCalculo'
					label='Porcento Base Cálculo'
					helperText='Informe os dados para o campo Porcento Base Calculo'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='tributPisModel.aliquotaPorcento'
					label='Alíquota Porcento'
					helperText='Informe os dados para o campo Aliquota Porcento'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributPisModel.aliquotaUnidade'
					label='Alíquota Unidade'
					helperText='Informe os dados para o campo Aliquota Unidade'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributPisModel.valorPrecoMaximo'
					label='Valor Preço Máximo'
					helperText='Informe os dados para o campo Valor Preco Maximo'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributPisModel.valorPautaFiscal'
					label='Valor Pauta Fiscal'
					helperText='Informe os dados para o campo Valor Pauta Fiscal'
					validate={[]}
				/>
			</Box>
		</Box>
	</>
);