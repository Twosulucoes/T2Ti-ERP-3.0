import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import tributIcmsCustomCab from '../page/tributIcmsCustomCab';
import tributConfiguraOfGt from '../page/tributConfiguraOfGt';
import tributGrupoTributario from '../page/tributGrupoTributario';
import tributOperacaoFiscal from '../page/tributOperacaoFiscal';
import tributIss from '../page/tributIss';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/tribut-grupo-tributario'
					state={{ _scrollToTop: true }}
					primaryText='Grupo Tributário'
					leftIcon={<tributGrupoTributario.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tribut-operacao-fiscal'
					state={{ _scrollToTop: true }}
					primaryText='Operação Fiscal'
					leftIcon={<tributOperacaoFiscal.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tribut-iss'
					state={{ _scrollToTop: true }}
					primaryText='ISS'
					leftIcon={<tributIss.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/tribut-icms-custom-cab'
					state={{ _scrollToTop: true }}
					primaryText='ICMS Customizado'
					leftIcon={<tributIcmsCustomCab.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tribut-configura-of-gt'
					state={{ _scrollToTop: true }}
					primaryText='Configura Tributação'
					leftIcon={<tributConfiguraOfGt.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
