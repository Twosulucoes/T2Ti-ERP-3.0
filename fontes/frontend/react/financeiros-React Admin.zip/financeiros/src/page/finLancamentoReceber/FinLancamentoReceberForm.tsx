/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FinParcelaReceberTab } from './FinParcelaReceberTab';

export const FinLancamentoReceberForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Lançamento a Receber">
				<FinLancamentoReceberTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Parcelas">
				<FinParcelaReceberTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FinLancamentoReceberTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};