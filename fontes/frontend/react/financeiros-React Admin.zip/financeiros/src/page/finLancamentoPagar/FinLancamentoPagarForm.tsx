/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FinParcelaPagarTab } from './FinParcelaPagarTab';

export const FinLancamentoPagarForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Lançamento a Pagar">
				<FinLancamentoPagarTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Parcelas">
				<FinParcelaPagarTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FinLancamentoPagarTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};