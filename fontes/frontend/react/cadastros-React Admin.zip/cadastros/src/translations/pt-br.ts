import { TranslationMessages } from 'react-admin';
import ptBrMessages from 'ra-language-pt-br';

const customPtBrMessages: TranslationMessages = {
	...ptBrMessages,
	ra: {
		...ptBrMessages.ra,
		configurable: {
			...ptBrMessages.ra.configurable,
			customize: 'Personalizar',
		},
		action: {
			...ptBrMessages.ra.action,
			select_columns: 'Colunas',
		},
	},
	dialogs: {
		confirm_delete_title: 'Confirmar Exclusão',
		confirm_delete_body: 'Tem certeza de que deseja excluir este endereço?',
		snackbar_delete_message: 'A exclusão será confirmada após o salvamento do registro.',
	},
	general: {
		adding: 'Adicionando...',
		editing: 'Editando...',
	},
	dashboard: {
		welcome: {
			title: 'Bem-vindo ao MVP gerado pelo Vycanis usando o react-admin',
			subtitle: 'Gere um dos servidores disponíveis no Vycanis para ver seu sistema funcionando. Acesse o site do Vycanis Modeler para mais ajuda e o site do react-admin para aprender a trabalhar com ele.',
			ra_button: 'Site do react-admin',
			vycanis_button: 'Site do Vycanis',
		},
		orders: {
			monthly_revenue: 'Receita Mensal',
			new_orders: 'Novos Pedidos',
			month_history: 'Receitas - Histórico de 30 dias',
			pending_orders: 'Pedidos Pendentes',
			items: '%{customer_name}, um item |||| %{customer_name}, %{nb_items} itens',
			last_reviews: 'Últimas Avaliações',
			all_reviews: 'Ver Todas as Avaliações',
			new_customers: 'Novos Clientes',
			all_customers: 'Ver Todos os Clientes',
		}
	},
	menu: {
		single_page: 'Telas Simples',
		master_page: 'Telas Agrupadas',
	},
	login_screen: {
		hint: 'Dica'
	},
	pos: {
		action: {
			change_theme: 'Mudar Tema',
		},
	}
};

export default customPtBrMessages;