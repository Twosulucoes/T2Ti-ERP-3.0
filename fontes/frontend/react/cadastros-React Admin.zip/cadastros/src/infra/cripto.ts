// Mesma cifra do backend (AES-256-CTR, PHP openssl_encrypt com OPENSSL_RAW_DATA + base64).
// A chave precisa ter 32 caracteres e o vetor 16, iguais aos do servidor.
const chave = import.meta.env.VITE_CHAVE_CRIPTOGRAFIA || '#Sua-Chave-de-32-caracteres-aqui';
const vetor = import.meta.env.VITE_VETOR_CRIPTOGRAFIA || '#Seu-Vetor-aqui#';

const codificador = new TextEncoder();

const importarChave = () =>
	crypto.subtle.importKey('raw', codificador.encode(chave), 'AES-CTR', false, ['encrypt', 'decrypt']);

const algoritmo = () => ({ name: 'AES-CTR', counter: codificador.encode(vetor), length: 128 });

export const cifrar = async (texto: string): Promise<string> => {
	const dados = await crypto.subtle.encrypt(algoritmo(), await importarChave(), codificador.encode(texto));
	return btoa(String.fromCharCode(...new Uint8Array(dados)));
};

export const decifrar = async (base64: string): Promise<string> => {
	const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
	const dados = await crypto.subtle.decrypt(algoritmo(), await importarChave(), bytes);
	return new TextDecoder().decode(dados);
};
