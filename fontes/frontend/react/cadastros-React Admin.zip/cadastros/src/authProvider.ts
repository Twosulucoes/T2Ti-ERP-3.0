import { AuthProvider, HttpError } from "react-admin";
import { cifrar, decifrar } from "./infra/cripto";

const apiUrl = import.meta.env.VITE_VYCANIS_SERVER;

export const authProvider: AuthProvider = {
  login: async ({ username, password }) => {
    const resposta = await fetch(`${apiUrl}/login`, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: await cifrar(JSON.stringify({ login: username, senha: password })),
    });

    if (!resposta.ok) {
      throw new HttpError("Usuário ou senha inválidos", resposta.status, {
        message: "Usuário ou senha inválidos",
      });
    }

    const { token, user } = await resposta.json();
    const usuario = JSON.parse(await decifrar(user));
    localStorage.setItem("token", await decifrar(token));
    localStorage.setItem(
      "user",
      JSON.stringify({
        id: usuario.idUsuario ?? usuario.id,
        fullName: usuario.pessoaNome ?? usuario.login,
      }),
    );
  },
  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    return Promise.resolve();
  },
  checkError: (error) => {
    const status = error?.status;
    if (status === 401 || status === 403) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      return Promise.reject();
    }
    return Promise.resolve();
  },
  checkAuth: () =>
    localStorage.getItem("token") ? Promise.resolve() : Promise.reject(),
  getPermissions: () => {
    return Promise.resolve(undefined);
  },
  getIdentity: () => {
    const persistedUser = localStorage.getItem("user");
    const user = persistedUser ? JSON.parse(persistedUser) : null;

    return Promise.resolve(user);
  },
};

export default authProvider;
