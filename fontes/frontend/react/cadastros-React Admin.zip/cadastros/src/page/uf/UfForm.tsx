/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const UfForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='sigla'
					label='Sigla'
					helperText='Informe os dados para o campo Sigla[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='codigoIbge'
					label='Codigo IBGE'
					helperText='Informe os dados para o campo Codigo IBGE'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);