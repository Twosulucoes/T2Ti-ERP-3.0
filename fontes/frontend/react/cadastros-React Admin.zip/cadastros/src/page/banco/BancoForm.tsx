/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";

export const BancoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<TextInput
					source='codigo'
					label='Código'
					helperText='Informe os dados para o campo Codigo[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={9}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[250]'
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='url'
					label='Url'
					helperText='Informe os dados para o campo Url[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='ispb'
					label='Ispb'
					helperText='Informe os dados para o campo Ispb[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Participa Compe'
					source='participaCompe'
					helperText='Informe os dados para o campo Participa Compe'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
		</Box>
	</SimpleForm>
);