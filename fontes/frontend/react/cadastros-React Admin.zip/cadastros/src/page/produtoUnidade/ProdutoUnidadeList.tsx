/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ProdutoUnidadeDomain from '../../data/domain/ProdutoUnidadeDomain';

const ProdutoUnidadeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["sigla","podeFracionar","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ProdutoUnidadeSmallScreenList : ProdutoUnidadeBigScreenList;

	return (
		<List
			title="Unidade Produto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ProdutoUnidadeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.sigla }
			secondaryText={ (record) => record.podeFracionar }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const ProdutoUnidadeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="sigla" label="Sigla" />
			<FunctionField
				label="Pode Fracionar"
				render={record => ProdutoUnidadeDomain.getPodeFracionar(record.podeFracionar)}
			/>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ProdutoUnidadeList;
