/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CfopList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","descricao","aplicacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CfopSmallScreenList : CfopBigScreenList;

	return (
		<List
			title="CFOP"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CfopSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.aplicacao }
		/>
	);
}

const CfopBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="aplicacao" label="Aplicacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CfopList;
