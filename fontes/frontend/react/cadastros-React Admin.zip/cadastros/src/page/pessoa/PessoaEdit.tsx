/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PessoaForm } from "./PessoaForm";
import { transformNestedData } from "../../infra/utils";

const PessoaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PessoaForm />
		</Edit>
	);
};

export default PessoaEdit;