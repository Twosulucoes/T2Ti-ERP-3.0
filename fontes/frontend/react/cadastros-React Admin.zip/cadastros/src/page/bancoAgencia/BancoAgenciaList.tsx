/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const BancoAgenciaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["bancoModel.nome","nome","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? BancoAgenciaSmallScreenList : BancoAgenciaBigScreenList;

	return (
		<List
			title="Agência"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const BancoAgenciaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.bancoModel.nome }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const BancoAgenciaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Banco" source="bancoModel.id" reference="banco" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="numero" label="Numero" />
			<TextField source="digito" label="Digito" />
			<FunctionField
				source="telefone"
				label="Telefone"
				render={record => formatWithMask(record.telefone, '(##)#####-####')}
			/>
			<TextField source="contato" label="Contato" />
			<TextField source="gerente" label="Gerente" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default BancoAgenciaList;
