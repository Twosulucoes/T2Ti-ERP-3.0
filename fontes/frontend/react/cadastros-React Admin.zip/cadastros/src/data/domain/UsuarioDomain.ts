class UsuarioDomain {
	static getAdministrador(administrador: string) { 
		switch (administrador) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAdministrador(administrador: string) { 
		switch (administrador) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default UsuarioDomain;