/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { AgendaNotificacaoTab } from './AgendaNotificacaoTab';
import { AgendaCompromissoConvidadoTab } from './AgendaCompromissoConvidadoTab';
import { ReuniaoSalaEventoTab } from './ReuniaoSalaEventoTab';

export const AgendaCompromissoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Compromissos">
				<AgendaCompromissoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Notificações">
				<AgendaNotificacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Convidados">
				<AgendaCompromissoConvidadoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Eventos">
				<ReuniaoSalaEventoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const AgendaCompromissoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};