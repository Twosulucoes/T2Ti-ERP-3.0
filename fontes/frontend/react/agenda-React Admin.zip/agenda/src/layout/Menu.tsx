import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import agendaCompromisso from '../page/agendaCompromisso';
import recadoRemetente from '../page/recadoRemetente';
import agendaCategoriaCompromisso from '../page/agendaCategoriaCompromisso';
import reuniaoSala from '../page/reuniaoSala';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/agenda-categoria-compromisso'
					state={{ _scrollToTop: true }}
					primaryText='Categoria Compromisso'
					leftIcon={<agendaCategoriaCompromisso.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/reuniao-sala'
					state={{ _scrollToTop: true }}
					primaryText='Sala de Reunião'
					leftIcon={<reuniaoSala.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/agenda-compromisso'
					state={{ _scrollToTop: true }}
					primaryText='Compromissos'
					leftIcon={<agendaCompromisso.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/recado-remetente'
					state={{ _scrollToTop: true }}
					primaryText='Recado'
					leftIcon={<recadoRemetente.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
