import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import ptBrMessages from './translations/pt-br';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import orcamentoFluxoCaixa from './page/orcamentoFluxoCaixa';
import orcamentoEmpresarial from './page/orcamentoEmpresarial';
import orcamentoFluxoCaixaPeriodo from './page/orcamentoFluxoCaixaPeriodo';
import orcamentoPeriodo from './page/orcamentoPeriodo';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'en') {
			return import('./translations/en').then(messages => messages.default);
		}

		// Português do Brasil é o idioma padrão
		return ptBrMessages;
	},
	'pt-br',
	[
		{ locale: 'pt-br', name: 'Português Brasil' },
		{ locale: 'en', name: 'English' },
	]
);

const store = localStorageStore(undefined, 'orcamentos');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Controle de Orçamentos (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='orcamento-fluxo-caixa' {...orcamentoFluxoCaixa} options={{ label: 'Orçamento - Fluxo de Caixa' }} />
			<Resource name='orcamento-empresarial' {...orcamentoEmpresarial} options={{ label: 'Orçamento' }} />
			<Resource name='orcamento-fluxo-caixa-periodo' {...orcamentoFluxoCaixaPeriodo} options={{ label: 'Períodos - Fluxo de Caixa' }} />
			<Resource name='orcamento-periodo' {...orcamentoPeriodo} options={{ label: 'Períodos do Orçamento' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;