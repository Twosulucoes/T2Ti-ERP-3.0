/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { OrcamentoEmpresarialForm } from "./OrcamentoEmpresarialForm";
import { transformNestedData } from "../../infra/utils";

const OrcamentoEmpresarialEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<OrcamentoEmpresarialForm />
		</Edit>
	);
};

export default OrcamentoEmpresarialEdit;