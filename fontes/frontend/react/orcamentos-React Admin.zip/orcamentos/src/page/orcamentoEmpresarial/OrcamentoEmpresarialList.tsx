/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const OrcamentoEmpresarialList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["orcamentoPeriodoModel.nome","nome","dataInicial"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OrcamentoEmpresarialSmallScreenList : OrcamentoEmpresarialBigScreenList;

	return (
		<List
			title="Orçamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OrcamentoEmpresarialSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.orcamentoPeriodoModel.nome }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.dataInicial }
		/>
	);
}

const OrcamentoEmpresarialBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Orcamento Periodo" source="orcamentoPeriodoModel.id" reference="orcamento-periodo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="dataInicial" label="Data Inicial" />
			<TextField source="numeroPeriodos" label="Numero Periodos" />
			<TextField source="dataBase" label="Data Base" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OrcamentoEmpresarialList;
