import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import orcamentoFluxoCaixa from '../page/orcamentoFluxoCaixa';
import orcamentoEmpresarial from '../page/orcamentoEmpresarial';
import orcamentoFluxoCaixaPeriodo from '../page/orcamentoFluxoCaixaPeriodo';
import orcamentoPeriodo from '../page/orcamentoPeriodo';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/orcamento-fluxo-caixa-periodo'
					state={{ _scrollToTop: true }}
					primaryText='Períodos - Fluxo de Caixa'
					leftIcon={<orcamentoFluxoCaixaPeriodo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/orcamento-periodo'
					state={{ _scrollToTop: true }}
					primaryText='Períodos do Orçamento'
					leftIcon={<orcamentoPeriodo.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/orcamento-fluxo-caixa'
					state={{ _scrollToTop: true }}
					primaryText='Orçamento - Fluxo de Caixa'
					leftIcon={<orcamentoFluxoCaixa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/orcamento-empresarial'
					state={{ _scrollToTop: true }}
					primaryText='Orçamento'
					leftIcon={<orcamentoEmpresarial.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
