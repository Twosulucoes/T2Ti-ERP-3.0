/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CrmSacCabecalhoForm } from "./CrmSacCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const CrmSacCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CrmSacCabecalhoForm />
		</Create>
	);
};

export default CrmSacCabecalhoCreate;