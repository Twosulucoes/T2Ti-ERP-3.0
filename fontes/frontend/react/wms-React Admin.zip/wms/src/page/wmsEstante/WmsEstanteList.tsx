/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const WmsEstanteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["wmsRuaModel.nome","codigo","quantidadeCaixa"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsEstanteSmallScreenList : WmsEstanteBigScreenList;

	return (
		<List
			title="Estante"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsEstanteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.wmsRuaModel.nome }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.quantidadeCaixa }
		/>
	);
}

const WmsEstanteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Wms Rua" source="wmsRuaModel.id" reference="wms-rua" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<TextField source="quantidadeCaixa" label="Quantidade Caixa" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsEstanteList;
