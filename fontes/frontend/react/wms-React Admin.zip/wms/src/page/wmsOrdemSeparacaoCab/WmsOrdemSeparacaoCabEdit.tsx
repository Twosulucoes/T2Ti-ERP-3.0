/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { WmsOrdemSeparacaoCabForm } from "./WmsOrdemSeparacaoCabForm";
import { transformNestedData } from "../../infra/utils";

const WmsOrdemSeparacaoCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<WmsOrdemSeparacaoCabForm />
		</Edit>
	);
};

export default WmsOrdemSeparacaoCabEdit;