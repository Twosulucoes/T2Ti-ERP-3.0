/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { WmsRecebimentoCabecalhoForm } from "./WmsRecebimentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const WmsRecebimentoCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<WmsRecebimentoCabecalhoForm />
		</Create>
	);
};

export default WmsRecebimentoCabecalhoCreate;