/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { WmsRecebimentoDetalheTab } from './WmsRecebimentoDetalheTab';

export const WmsRecebimentoCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Recebimento">
				<WmsRecebimentoCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens">
				<WmsRecebimentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const WmsRecebimentoCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};