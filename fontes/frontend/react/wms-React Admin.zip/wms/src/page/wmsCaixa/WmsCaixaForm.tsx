/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { WmsArmazenamentoTab } from './WmsArmazenamentoTab';

export const WmsCaixaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Caixa">
				<WmsCaixaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Armazenamento">
				<WmsArmazenamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const WmsCaixaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};