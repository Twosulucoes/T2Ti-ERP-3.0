/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { OsAberturaEquipamentoTab } from './OsAberturaEquipamentoTab';
import { OsProdutoServicoTab } from './OsProdutoServicoTab';
import { OsEvolucaoTab } from './OsEvolucaoTab';

export const OsAberturaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Abertura OS">
				<OsAberturaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Equipamentos">
				<OsAberturaEquipamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Produto ou Serviço">
				<OsProdutoServicoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Evolução">
				<OsEvolucaoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const OsAberturaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};