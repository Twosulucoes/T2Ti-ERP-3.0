# ordem_servico

## Instalação

Instale as dependências da aplicação executando:

```sh
npm install
```

## Desenvolvimento

Inicie a aplicação em modo de desenvolvimento executando:

```sh
npm run dev
```

## Produção

Gere a aplicação em modo de produção executando:

```sh
npm run build
```

## DataProvider

O data provider incluído usa o [ra-data-json-server](https://github.com/marmelab/react-admin/tree/master/packages/ra-data-json-server). Ele é adequado para APIs REST servidas pelo [JSON Server](https://github.com/typicode/json-server), como o [JSONPlaceholder](https://jsonplaceholder.typicode.com/).

Na raiz do projeto há um arquivo `.env` com a variável `VITE_JSON_SERVER_URL`. Defina nela a URL do seu backend. Por padrão, ela aponta para o [JSONPlaceholder](https://jsonplaceholder.typicode.com/).

## Idioma

A interface usa Português do Brasil (`pt-br`) como idioma padrão. O inglês (`en`) continua disponível como opção.
