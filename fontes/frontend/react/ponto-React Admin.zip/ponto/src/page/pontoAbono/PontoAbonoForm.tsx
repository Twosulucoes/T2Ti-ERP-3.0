/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PontoAbonoUtilizacaoTab } from './PontoAbonoUtilizacaoTab';

export const PontoAbonoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Abonos">
				<PontoAbonoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Utilização">
				<PontoAbonoUtilizacaoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PontoAbonoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};