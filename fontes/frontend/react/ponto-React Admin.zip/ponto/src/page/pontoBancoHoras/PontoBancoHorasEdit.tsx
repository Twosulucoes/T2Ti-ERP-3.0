/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PontoBancoHorasForm } from "./PontoBancoHorasForm";
import { transformNestedData } from "../../infra/utils";

const PontoBancoHorasEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PontoBancoHorasForm />
		</Edit>
	);
};

export default PontoBancoHorasEdit;