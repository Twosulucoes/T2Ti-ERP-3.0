/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { VendaOrcamentoDetalheTab } from './VendaOrcamentoDetalheTab';

export const VendaOrcamentoCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Orçamento de Venda">
				<VendaOrcamentoCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens do Orçamento">
				<VendaOrcamentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const VendaOrcamentoCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};