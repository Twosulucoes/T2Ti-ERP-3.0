/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { VendaCondicoesParcelasTab } from './VendaCondicoesParcelasTab';

export const VendaCondicoesPagamentoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Condições de Pagamento">
				<VendaCondicoesPagamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Parcelas">
				<VendaCondicoesParcelasTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const VendaCondicoesPagamentoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};