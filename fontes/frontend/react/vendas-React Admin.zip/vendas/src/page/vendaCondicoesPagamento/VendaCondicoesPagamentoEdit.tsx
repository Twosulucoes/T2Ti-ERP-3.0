/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { VendaCondicoesPagamentoForm } from "./VendaCondicoesPagamentoForm";
import { transformNestedData } from "../../infra/utils";

const VendaCondicoesPagamentoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<VendaCondicoesPagamentoForm />
		</Edit>
	);
};

export default VendaCondicoesPagamentoEdit;