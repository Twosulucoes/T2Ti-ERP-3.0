class FrotaVeiculoManutencaoDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'P': 
				return 'Preventiva'; 
			case 'C': 
				return 'Corretiva'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Preventiva': 
				return 'P'; 
			case 'Corretiva': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

}

export default FrotaVeiculoManutencaoDomain;